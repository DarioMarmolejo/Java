package com.example.SpringBatchHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
